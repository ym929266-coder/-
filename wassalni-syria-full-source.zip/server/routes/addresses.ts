import { Router } from 'express';
import { db } from '../db/database.js';
import { authenticate, AuthenticatedRequest } from '../middleware/auth.js';
import { Address } from '../types/index.js';

const router = Router();

// 1. Get all saved addresses for current user
router.get('/', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const userAddresses = db.addresses.filter(a => a.user_id === user.id);
  return res.json({
    success: true,
    addresses: userAddresses,
  });
});

// 2. Add new address
router.post('/', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const {
    title,
    city,
    district,
    street_details,
    building,
    floor,
    notes,
    latitude,
    longitude,
    is_default,
    phone_contact,
  } = req.body;

  if (!district || !street_details) {
    return res.status(400).json({
      success: false,
      message: 'يرجى تحديد الحي وتفاصيل الشارع للعنوان',
    });
  }

  // If this address is set to default, unset other defaults
  if (is_default) {
    db.addresses
      .filter(a => a.user_id === user.id)
      .forEach(a => {
        a.is_default = false;
      });
  }

  const existingUserAddresses = db.addresses.filter(a => a.user_id === user.id);
  const isFirstAddress = existingUserAddresses.length === 0;

  const newAddress: Address = {
    id: `addr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    user_id: user.id,
    title: title || 'عنوان جديد',
    city: city || 'دمشق',
    district,
    street_details,
    building: building || '',
    floor: floor || '',
    notes: notes || '',
    latitude: typeof latitude === 'number' ? latitude : 33.5138,
    longitude: typeof longitude === 'number' ? longitude : 36.2765,
    is_default: is_default !== undefined ? !!is_default : isFirstAddress,
    phone_contact: phone_contact || user.phone,
    created_at: new Date().toISOString(),
  };

  db.addresses.push(newAddress);
  db.save();

  return res.status(201).json({
    success: true,
    message: 'تم حفظ العنوان بنجاح',
    address: newAddress,
  });
});

// 3. Update existing address
router.put('/:id', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { id } = req.params;
  const address = db.addresses.find(a => a.id === id && a.user_id === user.id);

  if (!address) {
    return res.status(404).json({ success: false, message: 'العنوان غير موجود' });
  }

  const {
    title,
    city,
    district,
    street_details,
    building,
    floor,
    notes,
    latitude,
    longitude,
    is_default,
    phone_contact,
  } = req.body;

  if (is_default) {
    db.addresses
      .filter(a => a.user_id === user.id)
      .forEach(a => {
        a.is_default = false;
      });
    address.is_default = true;
  }

  if (title) address.title = title;
  if (city) address.city = city;
  if (district) address.district = district;
  if (street_details) address.street_details = street_details;
  if (building !== undefined) address.building = building;
  if (floor !== undefined) address.floor = floor;
  if (notes !== undefined) address.notes = notes;
  if (typeof latitude === 'number') address.latitude = latitude;
  if (typeof longitude === 'number') address.longitude = longitude;
  if (phone_contact) address.phone_contact = phone_contact;

  db.save();

  return res.json({
    success: true,
    message: 'تم تحديث العنوان بنجاح',
    address,
  });
});

// 4. Delete address
router.delete('/:id', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { id } = req.params;
  const index = db.addresses.findIndex(a => a.id === id && a.user_id === user.id);

  if (index === -1) {
    return res.status(404).json({ success: false, message: 'العنوان غير موجود' });
  }

  db.addresses.splice(index, 1);
  db.save();

  return res.json({
    success: true,
    message: 'تم حذف العنوان بنجاح',
  });
});

// 5. Set default address
router.post('/:id/default', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { id } = req.params;

  const target = db.addresses.find(a => a.id === id && a.user_id === user.id);
  if (!target) {
    return res.status(404).json({ success: false, message: 'العنوان غير موجود' });
  }

  db.addresses
    .filter(a => a.user_id === user.id)
    .forEach(a => {
      a.is_default = a.id === id;
    });

  db.save();

  return res.json({
    success: true,
    message: 'تم تعيين العنوان كافتراضي',
    address: target,
  });
});

export default router;
